<?php

    $host = "localhost";
    $username = "root";
    $password = "";


    try{
        $db_conn = new PDO("mysql:host=".$host.";dbname=citylight_bordereaux_db", $username, $password, array(PDO::ATTR_PERSISTENT => true));
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Connected successfully";
    }catch(PDOException $e){
        echo "Connection attempt failed ".$e->getMessage();
    }

    //$_SESSION['db_conn'] = $db_conn;
?>