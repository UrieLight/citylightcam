<?php
    include('database/db_connect.php');

    /*
    $fdate = '26/01/2022';
    $fdate = date_format_db($fdate);
    echo $fdate;

    function date_format_db($date){
        $exp_date = explode('/', $date);
        $db_date = $exp_date[2].'-'.$exp_date[1].'-'.$exp_date[0];
        return $db_date;
    }
    */

    $sql = "SELECT * FROM bordereaux ";
    $prepared_sql = $db_conn->prepare($sql);
    $prepared_sql->execute();

    echo '
    <div class="box-body" style="overflow: scroll;">
        <table id="example1" class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>Numéro Bordereau</th>
                    <th>Numéro conteneur</th>
                    <th>Nom Client</th>
                    <th>Numéro du Client</th>
                    <th>Marque</th>
                    <th>Nombre de Colis</th>
                    <th>Cubage souscris (Ligne)</th>
                    <th>Date d\'entree magazin</th>
                    <th>Prix total (FCFA)</th>
                    <th>Montant Perçu (FCFA)</th>
                    <th>Reste (FCFA)</th>
                    <th>Date de paiment</th>
                    <th>Mode de paiment</th>
                    <th>Statut</th>
                </tr>
            </thead>
            <tbody>';
                $row = $prepared_sql->fetchAll(PDO::FETCH_ASSOC);
                foreach($row as $bordereau){
                    echo '<tr>
                        <td>'.$bordereau['numero_bordereau'].'</td>
                        <td>'.$bordereau['numero_conteneur'].'</td>
                        <td>'.$bordereau['nom_client'].'</td>
                        <td>'.$bordereau['numero_client'].'</td>
                        <td>'.$bordereau['marque'].'</td>
                        <td>'.$bordereau['nombre_colis'].'</td>
                        <td>'.$bordereau['cubage'].'</td>
                        <td>'.$bordereau['date_entree_magazin'].'</td>
                        <td>'.$bordereau['prix_total'].'</td>
                        <td>'.$bordereau['montant_percu'].'</td>
                        <td>'.$bordereau['reste'].'</td>
                        <td>'.$bordereau['date_paiement'].'</td>
                        <td>'.$bordereau['mode_paiement'].'</td>
                        <td>'.$bordereau['statut'].'</td>
                    </tr>';
                }

            echo '
            </tbody>
        </table>
    </div>';
?>